# Urosaurus nigricaudus synteny analysis with Circos.

# Genes that were found with the U.nigricaudus genome annotation process were aligned to the genome of reference of the other reptiles, using BWA. 
# From the bwa alignment only the best hits for each gene from scaffolds 1 to 14 of  U.nigricaudus were retained. 
# Circos requiers three files for each synteny analysis: two files named "karyotype" to delimit number and size of chromosomes for each species, and a file that indicates the position of the genes on each genome to draw the links between the genomes. The three files for each analysis are provided. 
# The links files contain the scaffolds where each gene is found, the start and end position of the gene (according to the gff from the annotation), the chromosome and start and end position of that same gene in the target genome (according to the bwa alignment), and the color of the link.
# The path to the "karyotype" and links files are provided to the program  within a file called unigcircos.conf  which circos uses to build the synteny image as follows:

circos -conf unigcircos.conf

# To obtain every synteny image, the files in the unigcircos.conf file must be changed accordingly to each species.        
