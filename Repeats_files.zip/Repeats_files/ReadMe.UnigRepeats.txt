# Unig_Repeats_Pipeline.
# NOTE: This pipeline was also applied to Sceloporus undulatus, Phrynosoma platyrhinos and Pogona vitticeps genome, for comparative purposes. 

# Using Dfam plus Repbase databases.

# We performed Repeat identification and classificacion following tutorial by Dr. Daren Card (https://darencard.net/blog/2022-07-09-genome-repeat-annotation/).
# We used a slightly modified version of bash script "repclassifier" developed by Dr. Card which is  publicly available at https://github.com/darencard/GenomeAnnotation/blob/master/repclassifier.
# Our modified version of the script is called "repclassifier_no-nolow" and it performs the same analysis but  without the -nolow flag.

# First step is to identify de novo repeat content with RepeatModeler. 


# Building database.

mkdir -p logs
BuildDatabase -name UNIG -engine ncbi unigricaudus.clean_assembly.final.fasta

# RepeatModeler. 

RepeatModeler -pa 10 -LTRStruct -engine ncbi -database UNIG 2>&1 | tee logs/00_repeatmodeler.log


# Tunning RepeatModeler results.

# Add a prefix for species using seqkit and awk: UroNig1 for genera,spp and 1 stands for 1st genome assembly. 

cat UNIG-families.fa | seqkit fx2tab | awk '{ print "UroNig1_"$0 }' | seqkit tab2fx > UNIG-families.prefix.fa

# Splitting unkown elements from classified elements.

cat UNIG-families.prefix.fa | seqkit fx2tab | grep -v "Unknown" | seqkit tab2fx > UNIG-families.prefix.fa.known
cat UNIG-families.prefix.fa | seqkit fx2tab | grep "Unknown" | seqkit tab2fx > UNIG-families.prefix.fa.unknown

# counting known and unkwon elements

grep -c ">" UNIG-families.prefix.fa.known
#322
grep -c ">" UNIG-families.prefix.fa.unknown
#1851

# Using repclassifier_no-nolow

# Classifying unknowns (-u): run with 4 threads/cores (-t) and using the Tetrapoda elements (-d) from Repbase
# and known elements (-k) from the same reference genome; append newly identified elements to the existing known 
# element library (-a) and write results to an output directory (-o).

screen
conda activate repeatmasker-repbase
export PATH=$PATH:/usr/local/bioconda/bin
export LC_ALL=C #removes perl warnings

./repclassifier_no-nolow -t 4 -d Tetrapoda -u UNIG-families.prefix.fa.unknown -k UNIG-families.prefix.fa.known -a UNIG-families.prefix.fa.known -o round-1_UNIGTetrapoda-Self


# output: counting known and unknown elements

grep -c ">" round-1_UNIGTetrapoda-Self.known 
# 978 (increase from 322).
grep -c ">" round-1_UNIGTetrapoda-Self.unknown 
# 1195 (decrease from 1851).

# Second round of repclassifier

./repclassifier_no-nolow -t 4 -u round-1_UNIGTetrapoda-Self/round-1_UNIGTetrapoda-Self.unknown -k round-1_UNIGTetrapoda-Self/round-1_UNIGTetrapoda-Self.known -a round-1_UNIGTetrapoda-Self/round-1_UNIGTetrapoda-Self.known -o round-2_UNIGSelf

#output: 
grep -c ">" round-2_UNIGSelf.known 
# 1347 (increase)
grep -c ">" round-2_UNIGSelf.unknown 
# 826 (decrease)

# Third and subsequent rounds of repeatclassifier.

./repclassifier_no-nolow -t 4 -u round-2_UNIGSelf/round-2_UNIGSelf.unknown -k round-2_UNIGSelf/round-2_UNIGSelf.known -a round-2_UNIGSelf/round-2_UNIGSelf.known -o round-3_UNIGSelf

# output:
grep -c ">" round-3_UNIGSelf.known
# 1479 (increase)
grep -c ">" round-3_UNIGSelf.unknown 
# 694 (decrease)

./repclassifier_no-nolow -t 4 -u round-3_UNIGSelf/round-3_UNIGSelf.unknown -k round-3_UNIGSelf/round-3_UNIGSelf.known -a round-3_UNIGSelf/round-3_UNIGSelf.known -o round-4_UNIGSelf

#output: 
grep -c ">" round-4_UNIGSelf.known 
# 1535 (increase)
grep -c ">" round-4_UNIGSelf.unknown 
# 638 (decrease)

./repclassifier_no-nolow -t 4 -u round-4_UNIGSelf/round-4_UNIGSelf.unknown -k round-4_UNIGSelf/round-4_UNIGSelf.known -a round-4_UNIGSelf/round-4_UNIGSelf.known -o round-5_UNIGSelf

#output: 
grep -c ">" round-5_UNIGSelf.known 
# 1553 (increase)
grep -c ">" round-5_UNIGSelf.unknown 
# 620 (decrease)

./repclassifier_no-nolow -t 4 -u round-5_UNIGSelf/round-5_UNIGSelf.unknown -k round-5_UNIGSelf/round-5_UNIGSelf.known -a round-5_UNIGSelf/round-5_UNIGSelf.known -o round-6_UNIGSelf

#output: 
grep -c ">" round-6_UNIGSelf.known 
# 1564 (increase)
grep -c ">" round-6_UNIGSelf.unknown 
# 609 (decrease)

./repclassifier_no-nolow -t 4 -u  round-6_UNIGSelf/round-6_UNIGSelf.unknown -k round-6_UNIGSelf/round-6_UNIGSelf.known -a round-6_UNIGSelf/round-6_UNIGSelf.known -o round-7_UNIGSelf

#output: 
grep -c ">" round-7_UNIGSelf.known 
# 1564
grep -c ">" round-7_UNIGSelf.unknown 
# 609 
# no more increase of known at this point.

# Now full Repeat Annotation and Masking in different rounds according to repeat type.

# Creating output directories

mkdir -p 01_simple_out 02_tetrapoda_out 03_known_out 04_unknown_out

# RepeatMasker Round 1: annotate/mask simple repeats in genome.fasta (-noint -xsmall options). Added the -species eukaryota option because default was human.

conda activate repeatmasker-repbase

RepeatMasker -pa 6 -a -e ncbi -species eukaryota -dir 01_simple_out -noint -xsmall unigricaudus.clean_assembly.final.fasta 2>&1 | tee logs/01_simplemask.log

# output in : 01_simple_out
# rename outputs

rename fasta simple_mask 01_simple_out/unigricaudus.clean_assembly.final*
rename .masked .masked.fasta 01_simple_out/unigricaudus.clean_assembly.final*


# RepeatMasker Round 2: annotate/mask tetrapoda elements sourced from Dfam_Repbase library  using output from 1st round of RepeatMasker. 
# Here I use -nolow, because simple repeats are already masked. 

RepeatMasker -pa 6 -a -e ncbi -dir 02_tetrapoda_out -nolow -species tetrapoda 01_simple_out/unigricaudus.clean_assembly.final.simple_mask.masked.fasta 2>&1 | tee logs/02_tetrapodamask.log

# rename outputs
rename simple_mask.masked.fasta tetrapoda_mask 02_tetrapoda_out/unigricaudus.clean_assembly.final.*
rename .masked .masked.fasta 02_tetrapoda_out/unigricaudus.clean_assembly.final.*

# RepeatMasker Round 3: annotate/mask known elements sourced from species-specific de novo repeat library (last round of repeatclassifier) using output from 2nd round of RepeatMasker

RepeatMasker -pa 6 -a -e ncbi -dir 03_known_out -nolow -lib round-7_UNIGSelf/round-7_UNIGSelf.known 02_tetrapoda_out/unigricaudus.clean_assembly.final.tetrapoda_mask.masked.fasta 2>&1 | tee logs/03_knownmask.log

# rename outputs
rename tetrapoda_mask.masked.fasta known_mask 03_known_out/unigricaudus.clean_assembly.final.*
rename .masked .masked.fasta 03_known_out/unigricaudus.clean_assembly.final.*

# RepeatMasker Round 4: annotate/mask unknown elements sourced from species-specific de novo repeat library using output from 3rd round of RepeatMasker

RepeatMasker -pa 6 -a -e ncbi -dir 04_unknown_out -nolow -lib round-7_UNIGSelf/round-7_UNIGSelf.unknown 03_known_out/unigricaudus.clean_assembly.final.known_mask.masked.fasta 2>&1 | tee logs/04_unknownmask.log

# rename outputs
rename known_mask.masked.fasta unknown_mask 04_unknown_out/unigricaudus.clean_assembly.final.*
rename .masked .masked.fasta 04_unknown_out/unigricaudus.clean_assembly.final.*

# Combine everything together to build a full summary of the repeat element landscape of our reference genome.

# Create directory for full results

mkdir 05_full_out

# Combine full RepeatMasker result files - .cat.gz

cat 01_simple_out/unigricaudus.clean_assembly.final.simple_mask.cat.gz 02_tetrapoda_out/unigricaudus.clean_assembly.final.tetrapoda_mask.cat.gz 03_known_out/unigricaudus.clean_assembly.final.known_mask.cat.gz 04_unknown_out/unigricaudus.clean_assembly.final.unknown_mask.cat.gz > 05_full_out/unigricaudus.clean_assembly.final.full_mask.cat.gz

# Combine RepeatMasker tabular files for all repeats - .out
# tail: use -n +K to output starting with the Kth line.

cat 01_simple_out/unigricaudus.clean_assembly.final.simple_mask.out <(cat 02_tetrapoda_out/unigricaudus.clean_assembly.final.tetrapoda_mask.out | tail -n +4) <(cat 03_known_out/unigricaudus.clean_assembly.final.known_mask.out | tail -n +4) <(cat 04_unknown_out/unigricaudus.clean_assembly.final.unknown_mask.out | tail -n +4) > 05_full_out/unigricaudus.clean_assembly.final.full_mask.out

# Copy RepeatMasker tabular files for simple repeats - .out

cat 01_simple_out/unigricaudus.clean_assembly.final.simple_mask.out > 05_full_out/unigricaudus.clean_assembly.final.simple_mask.out

# Combine RepeatMasker tabular files for complex, interspersed repeats - .out

cat 02_tetrapoda_out/unigricaudus.clean_assembly.final.tetrapoda_mask.out <(cat 03_known_out/unigricaudus.clean_assembly.final.known_mask.out | tail -n +4) <(cat 04_unknown_out/unigricaudus.clean_assembly.final.unknown_mask.out | tail -n +4) > 05_full_out/unigricaudus.clean_assembly.final.complex_mask.out

# Combine RepeatMasker repeat alignments for all repeats - .align

cat 01_simple_out/unigricaudus.clean_assembly.final.simple_mask.align 02_tetrapoda_out/unigricaudus.clean_assembly.final.tetrapoda_mask.align 03_known_out/unigricaudus.clean_assembly.final.known_mask.align 04_unknown_out/unigricaudus.clean_assembly.final.unknown_mask.align > 05_full_out/unigricaudus.clean_assembly.final.full_mask.align

# Compressing files to save space

find . -type f -name "*.align" | sort | while read file; do gzip ${file}; done
find . -type f -name "*.out" | sort | while read file; do gzip ${file}; done
find . -type f -name "*.fasta" | sort | while read file; do gzip ${file}; done 

# Generate a new combined .tbl summary table of repeat composition using ProcessRepeats.
# Resummarize repeat compositions from combined analysis of all RepeatMasker rounds
# ProcessRepeats - Post process results from RepeatMasker and produce anannotation file.
# SYNOPSIS: ProcessRepeats [-options] <RepeatMasker *.cat file>

# Warning: the following produces another full_mask.align file, make sure to gzip the first one or rename it to distinguish them

conda activate repeatmasker-repbase
ProcessRepeats -a -gff -species tetrapoda 05_full_out/unigricaudus.clean_assembly.final.full_mask.cat.gz 2>&1 | tee logs/05_fullmask.log

# Generating repeat-family–specific alignments and calculating the average Kimura-2-parameter divergence from consensus within each family, correcting for high mutation rates at CpG sites with the calcDivergenceFromAlign.pl RepeatMasker tool.
# path /usr/local/bioconda/envs/repeatmasker/share/RepeatMasker/util/calcDivergenceFromAlign.pl

/usr/local/bioconda/envs/repeatmasker/share/RepeatMasker/util/calcDivergenceFromAlign.pl -s UNIG.repeat_divergence.tbl 05_full_out/unigricaudus.clean_assembly.final.full_mask.2.align

# Create graph with createRepeatLandscape.pl
# path /usr/local/bioconda/envs/repeatmasker/share/RepeatMasker/util/createRepeatLandscape.pl

/usr/local/bioconda/envs/repeatmasker/share/RepeatMasker/util/createRepeatLandscape.pl -div UNIG.repeat_divergence.tbl -t "Urosaurus nigricaudus" -g 1870054407 > UNIG.repeat_divergence.html

# END
