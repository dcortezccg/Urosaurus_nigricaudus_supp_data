#######################################
#    RNAseq tails  U.nigricaudus      #
#######################################

par(mfrow= c(1,3))

M1 = read.table("/PATH/RNAseq_U_nigricaudus_coverage/Male1.sorted.uniq.chr14.bed", header = F); head(M1)
F1 = read.table("/PATH/RNAseq_U_nigricaudus_coverage/Female1.sorted.uniq.chr14.bed", header = F); head(F1)
M2 = read.table("/PATH/RNAseq_U_nigricaudus_coverage/Male2.sorted.uniq.chr14.bed", header = F); head(M2)
F2 = read.table("/PATH/RNAseq_U_nigricaudus_coverage/Female2.sorted.uniq.chr14.bed", header = F); head(F2)
#M1$V4 = M1$V4 +1; head(M1$V4)
#F1$V4 = F1$V4 +1; head(F1$V4)
#M2$V4 = M2$V4 +1; head(M2$V4)
#F2$V4 = F2$V4 +1; head(F2$V4)
#male = M1$V4+M2$V4
#female = F1$V4 + F2$V4

male = M1$V4
female = F1$V4
male2 = M2$V4
female2 = F2$V4


#M1$V4[M1$V4==0] <- NA; M1$V4
#F1$V4[F1$V4==0] <- NA; F1$V4
#M2$V4[M2$V4==0] <- NA; M2$V4
#F2$V4[F2$V4==0] <- NA; F2$V4
#male14 = M1$V4
#female14 = F1$V4
#Tmale14 = M2$V4
#Tfemale14 = F2$V4
#Rfemale1 = female1+Tfemale1

ratio = log2(male/female)
ll = length(ratio); len=c(1:ll); length(len)
plot(len,ratio, ylim=c(-10,20), type="p", pch = 16, cex = 0.8, col="coral1")
abline(h=0)
ratio = log2(male2/female2)
plot(len,ratio, ylim=c(-10,20), type="p", pch = 16, cex = 0.8, col="coral4")
abline(h=0)

abline(v=430)
abline(v=240)




#########################################
#  RNAseq Coverage Plots U.bicarinatus  #
#########################################

Scaf1male <- read.csv("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_1__1_contigs__length_334926328.male.rnaseq.cov.50", header=FALSE, sep = "\t")
head (Scaf1male)
Scaf1female <- read.csv("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_1__1_contigs__length_334926328.female.rnaseq.cov.50", header=FALSE, sep = "\t")
head (Scaf1female)

div = log2(Scaf1male/Scaf1female)
boxplot(div, ylim=c(-0.1,0.1))

head(div)
dim(div)
length(len)


par(mfrow= c(1,1))

sf1 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_1__1_contigs__length_334926328.female.rnaseq.cov.50"); 
sf2 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_1__1_contigs__length_334926328.male.rnaseq.cov.50");
CountsA = sf1[1:19485,]
CountsB = sf2[1:19485,]
dim(CountsA); dim(CountsB)
sf3=log2(CountsA$V4/CountsB$V4)
plot(sf3,type="p", ylim=c(-20,20), col="lightsteelblue4", pch = 16, cex = 0.5); abline(h=0, col="red")

sf1 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_1__1_contigs__length_334926328.female.sorted.cov.bed"); 
sf2 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_1__1_contigs__length_334926328.male.sorted.cov.bed");
dim(sf1);dim(sf2)
CountsA = sf1[1:297655,]
CountsB = sf2[1:297655,]
dim(CountsA); dim(CountsB)
sf3=log2(CountsA$V4/CountsB$V4)
plot(sf3,type="p", ylim=c(-20,20), col="coral2", pch = 16, cex = 0.5); abline(h=0, col="red")


sf1 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_1__1_contigs__length_334926328.female.rnaseq.cov.50"); sf1$V1[sf1$V1 == 1] = NA
sf2 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_2__1_contigs__length_279651830.female.rnaseq.cov.50"); sf2$V1[sf2$V1 == 1] = NA
sf3 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_3__3_contigs__length_380405208.female.rnaseq.cov.50"); sf3$V1[sf3$V1 == 1] = NA
sf4 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_4__1_contigs__length_204779671.female.rnaseq.cov.50"); sf4$V1[sf4$V1 == 1] = NA
sf5 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_5__3_contigs__length_255663841.female.rnaseq.cov.50"); sf5$V1[sf5$V1 == 1] = NA
sf6 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_6__1_contigs__length_127361694.female.rnaseq.cov.50"); sf6$V1[sf6$V1 == 1] = NA
sf7 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_7__1_contigs__length_63119002.female.rnaseq.cov.50"); sf7$V1[sf7$V1 == 1] = NA
sf8 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_8__1_contigs__length_34429484.female.rnaseq.cov.50"); sf8$V1[sf8$V1 == 1] = NA
sf9 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_9__1_contigs__length_29550192.female.rnaseq.cov.50"); sf9$V1[sf9$V1 == 1] = NA
sf10 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_10__1_contigs__length_28428771.female.rnaseq.cov.50"); sf10$V1[sf10$V1 == 1] = NA
sf11 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_11__1_contigs__length_26404583.female.rnaseq.cov.50"); sf11$V1[sf11$V1 == 1] = NA
sf12 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_12__1_contigs__length_25999424.female.rnaseq.cov.50"); sf12$V1[sf12$V1 == 1] = NA
sf13 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_13__1_contigs__length_25378550.female.rnaseq.cov.50"); sf13$V1[sf13$V1 == 1] = NA
sf14 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_14__1_contigs__length_22169564.female.rnaseq.cov.50"); sf14$V1[sf14$V1 == 1] = NA
sf15 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_15__1_contigs__length_1600545.female.rnaseq.cov.50"); sf15$V1[sf15$V1 == 1] = NA
sf16 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_16__1_contigs__length_1131946.female.rnaseq.cov.50"); sf16$V1[sf16$V1 == 1] = NA

#boxplot(sf1$V1,sf2$V1,sf3$V1,sf4$V1,sf5$V1,sf6$V1,sf7$V1,sf8$V1,sf9$V1,sf10$V1,
#        sf11$V1,sf12$V1,sf13$V1,sf14$V1,sf15$V1,sf16$V1, col="lightsteelblue2", ylim=c(0,50));
#abline(h=0, col="red")

xf1 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_1__1_contigs__length_334926328.male.rnaseq.cov.50");  xf1$V1[xf1$V1 == 1] = NA
xf2 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_2__1_contigs__length_279651830.male.rnaseq.cov.50");  xf2$V1[xf2$V1 == 1] = NA
xf3 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_3__3_contigs__length_380405208.male.rnaseq.cov.50");  xf3$V1[xf3$V1 == 1] = NA
xf4 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_4__1_contigs__length_204779671.male.rnaseq.cov.50");  xf4$V1[xf4$V1 == 1] = NA
xf5 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_5__3_contigs__length_255663841.male.rnaseq.cov.50");  xf5$V1[xf5$V1 == 1] = NA
xf6 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_6__1_contigs__length_127361694.male.rnaseq.cov.50");  xf6$V1[xf6$V1 == 1] = NA
xf7 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_7__1_contigs__length_63119002.male.rnaseq.cov.50");  xf7$V1[xf7$V1 == 1] = NA
xf8 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_8__1_contigs__length_34429484.male.rnaseq.cov.50");  xf8$V1[xf8$V1 == 1] = NA
xf9 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_9__1_contigs__length_29550192.male.rnaseq.cov.50");  xf9$V1[xf9$V1 == 1] = NA
xf10 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_10__1_contigs__length_28428771.male.rnaseq.cov.50");  xf10$V1[xf10$V1 == 1] = NA
xf11 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_11__1_contigs__length_26404583.male.rnaseq.cov.50");  xf11$V1[xf11$V1 == 1] = NA
xf12 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_12__1_contigs__length_25999424.male.rnaseq.cov.50");  xf12$V1[xf12$V1 == 1] = NA
xf13 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_13__1_contigs__length_25378550.male.rnaseq.cov.50");  xf13$V1[xf13$V1 == 1] = NA
xf14 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_14__1_contigs__length_22169564.male.rnaseq.cov.50");  xf14$V1[xf14$V1 == 1] = NA
xf15 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_15__1_contigs__length_1600545.male.rnaseq.cov.50");  xf15$V1[xf15$V1 == 1] = NA
xf16 = read.table("/PATH/RNAseq_U_bicarinatus_coverage/Scaffold_16__1_contigs__length_1131946.male.rnaseq.cov.50");  xf16$V1[xf16$V1 == 1] = NA

#boxplot(sf1$V1,sf2$V1,sf3$V1,sf4$V1,sf5$V1,sf6$V1,sf7$V1,sf8$V1,sf9$V1,sf10$V1,
#        sf11$V1,sf12$V1,sf13$V1,sf14$V1,sf15$V1,sf16$V1, col="coral2", ylim=c(0,50));

variable1 = log2(xf1$V1/sf1$V1); #variable1[variable1 == 0] = NA
variable2 = log2(xf2$V1/sf2$V1); #variable2[variable2 == 0] = NA
variable3 = log2(xf3$V1/sf3$V1); #variable3[variable3 == 0] = NA
variable4 = log2(xf4$V1/sf4$V1); #variable4[variable4 == 0] = NA
variable5 = log2(xf5$V1/sf5$V1); #variable5[variable5 == 0] = NA
variable6 = log2(xf6$V1/sf6$V1); #variable6[variable6 == 0] = NA
variable7 = log2(xf7$V1/sf7$V1); #variable7[variable7 == 0] = NA
variable8 = log2(xf8$V1/sf8$V1); #variable8[variable8 == 0] = NA
variable9 = log2(xf9$V1/sf9$V1); #variable9[variable9 == 0] = NA
variable10 = log2(xf10$V1/sf10$V1); #variable10[variable10 == 0] = NA
variable11 = log2(xf11$V1/sf11$V1); #variable11[variable11 == 0] = NA
variable12 = log2(xf12$V1/sf12$V1); #variable12[variable12 == 0] = NA
variable13 = log2(xf13$V1/sf13$V1); #variable13[variable13 == 0] = NA
variable14 = log2(xf14$V1/sf14$V1); #variable14[variable14 == 0] = NA
variable15 = log2(xf15$V1/sf15$V1); #variable15[variable15 == 0] = NA
variable16 = log2(xf16$V1/sf16$V1); #variable16[variable16 == 0] = NA

boxplot(variable1, variable2, variable3, variable4, variable5, variable6, variable7, variable8, variable9, variable10,
        variable11, variable12, variable13, variable14, variable15, variable16,
        col=c("lightsteelblue2","lightsteelblue2","lightsteelblue2","lightsteelblue2","lightsteelblue2","lightsteelblue2","lightsteelblue2","lightsteelblue2",
              "lightsteelblue2","lightsteelblue2","lightsteelblue2","lightsteelblue2","lightsteelblue2","coral2","coral4","coral4","lightsteelblue2",
              "lightsteelblue2","lightsteelblue2","lightsteelblue2","lightsteelblue2","lightsteelblue2","lightsteelblue2","lightsteelblue2","coral1"
              ,"lightsteelblue2","lightsteelblue2","lightsteelblue2"), ylim=c(-4,4))
abline(h=0)




#######################################
#   RNAseq per tissue  U.bicarinatus  #
#######################################

Scaf14nbrainF <- read.csv("/PATH/RNAseq_U_bicarinatus_coverage/UbiBrF_1.tuned.rpkm.chrX.bed.corrected", header=FALSE, sep = "\t")
Scaf14nbrainM <- read.csv("/PATH/RNAseq_U_bicarinatus_coverage/UbiBrM_1.tuned.rpkm.chrX.bed.corrected", header=FALSE, sep = "\t")
head(Scaf14nbrainF); head(Scaf14nbrainM)

Scaf14nheartF <- read.csv("/PATH/RNAseq_U_bicarinatus_coverage/UbiHtF_1.tuned.rpkm.chrX.bed.corrected", header=FALSE, sep = "\t")
Scaf14nheartM <- read.csv("/PATH/RNAseq_U_bicarinatus_coverage/UbiHtM_1.tuned.rpkm.chrX.bed.corrected", header=FALSE, sep = "\t")

Scaf14nkidneyF <- read.csv("/PATH/RNAseq_U_bicarinatus_coverage/UbiKdF_1.tuned.rpkm.chrX.bed.corrected", header=FALSE, sep = "\t")
Scaf14nkidneyM <- read.csv("/PATH/RNAseq_U_bicarinatus_coverage/UbiKdM_1.tuned.rpkm.chrX.bed.corrected", header=FALSE, sep = "\t")

Scaf14nliverF <- read.csv("/PATH/RNAseq_U_bicarinatus_coverage/UbiLvF_1.tuned.rpkm.chrX.bed.corrected", header=FALSE, sep = "\t")
Scaf14nliverM <- read.csv("/PATH/RNAseq_U_bicarinatus_coverage/UbiLvM_1.tuned.rpkm.chrX.bed.corrected", header=FALSE, sep = "\t")

Scaf14nbrainM$V4 =Scaf14nbrainM$V4+1; Scaf14nbrainF$V4=Scaf14nbrainF$V4+1
br2 = log2(Scaf14nbrainM$V4/Scaf14nbrainF$V4)

Scaf14nheartM$V4 =Scaf14nheartM$V4+1; Scaf14nheartF$V4=Scaf14nheartF$V4+1
ht2 = log2(Scaf14nheartM$V4/Scaf14nheartF$V4)

Scaf14nkidneyM$V4 =Scaf14nkidneyM$V4+1; Scaf14nkidneyF$V4=Scaf14nkidneyF$V4+1
kd2 = log2(Scaf14nkidneyM$V4/Scaf14nkidneyF$V4)

Scaf14nliverM$V4 =Scaf14nliverM$V4+1; Scaf14nliverF$V4=Scaf14nliverF$V4+1
lv2 = log2(Scaf14nliverM$V4/Scaf14nliverF$V4); length(lv2)

boxplot(br,ht,kd,lv,br2,ht2,kd2,lv2, ylim=c(-1,1))
abline(h=0,col="red")

