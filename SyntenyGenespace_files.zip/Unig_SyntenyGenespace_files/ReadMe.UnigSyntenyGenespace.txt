# Urosaurus nigricaudus synteny with Genespace.

# Gff and protein fasta files were downloaded from NCBI website (https://www.ncbi.nlm.nih.gov) for species: Sceloporus undulatus, Phrynosoma platyrhinos, Anolis carolinensis, Thamnophis elegans and Podarcis muralis.

# Gff and protein fasta files for Naja naja were downloaded from Ensembl website (https://www.ensembl.org/Naja_naja/Info/Index).

# Result from this Genespace run is provided as gsParam.rda file.

# Further editing of image, for better visualization, was done in Adobe Illustrator: a) labels were changed from chromosome name to chromosome number; b) a divergence time tree between the species was added, following the divergence estimations provided by timetree.org (https://timetree.org).

