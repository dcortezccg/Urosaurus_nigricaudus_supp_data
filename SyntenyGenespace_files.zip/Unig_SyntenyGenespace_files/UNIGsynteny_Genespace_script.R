library(GENESPACE)

# Paths to data.

genomeRepo <- "/path/to/directory/with/gffs/and/protein/fastas/ReptileData"
wd <- "/path/to/Genespace/working/directory/UnigSyntenyWD"
path2mcscanx <- "/path/to/MCScanX-master"

# Building input files according to genespace requirements.

# Parsing Urosaurus file.

parsedPaths <- parse_annotations(
rawGenomeRepo = genomeRepo, 
genomeDirs = "Urosaurus_nigricaudus",
genomeIDs = "U.nigricaudus",
gffString = "gff",
faString = "faa",
headerEntryIndex = 1,
gffIdColumn = "Name",
genespaceWd = wd)

# Parsing Indian Cobra file (data comes from Ensemble as NCBI´s gff is incomplete).

parsedPaths3 <- parse_annotations(
  rawGenomeRepo = genomeRepo, 
  genomeDirs = "Naja_naja",
  genomeIDs = "N.naja",
  gffString = "gff",
  faString = "faa",
  headerEntryIndex = 1,
  headerStripText = '[.][^.]+$', #removes info after the . in the protein name.
  gffIdColumn = "protein_id",
  genespaceWd = wd)

# Parsing the other reptile files (left out A. sagrei because no gff or protein-fasta available).

genomes2run <- c("Anolis_carolinensis","Phrynosoma_platyrhinos","Podarcis_muralis","Sceloporus_undulatus","Thamnophis_elegans")
parsedPaths2 <- parse_annotations(
rawGenomeRepo = genomeRepo,
genomeDirs = genomes2run,
genomeIDs = c("A.carolinensis","P.platyrhinos","P.muralis","S.undulatus","T.elegans"),
gffString = "gff",
faString = "faa",
headerEntryIndex = 1,
gffIdColumn = "protein_id",
genespaceWd = wd)

# Initialize Genespace.
# Make sure orthofinder env is activated (recommended: launch R from orthofinder env).

# init_genespace will check input data and make directories.

gpar <- init_genespace(
  wd = wd,
  path2mcscanx = path2mcscanx)

# Genespace run (this takes several hours).

out <- run_genespace(gpar, overwrite = T)


# When finished, load gsParams.rda

load('/path/to/UnigSyntenyWD/results/gsParams.rda', verbose = TRUE)

# Placed gsParam into an object.

ortologs <- gsParam

# Plotting.
# White background plots.

ggthemes <- ggplot2::theme(
  panel.background = ggplot2::element_rect(fill = "white"))
customPal <- colorRampPalette(
  c("orange3","darkblue","brown","skyblue","green4","gold","purple"))

synteny_white_labels <-plot_riparian(gsParam = ortologs,
                                     palette = customPal,
                                     braidAlpha = .65,
                                     chrFill = "lightgrey",
                                     addThemes = ggthemes,
                                     refGenome= "U.nigricaudus",
                                     genomeIDs = c("P.muralis","N.naja","T.elegans","A.carolinensis","P.platyrhinos", "S.undulatus","U.nigricaudus"),
                                     minChrLen2plot = 0,
                                     useOrder = TRUE,
                                     useRegions = TRUE)

synteny_white_nolabels <-plot_riparian(gsParam = ortologs,
                                     palette = customPal,
                                     braidAlpha = .65,
                                     chrFill = "lightgrey",
                                     addThemes = ggthemes,
                                     refGenome= "U.nigricaudus",
                                     genomeIDs = c("P.muralis","N.naja","T.elegans","A.carolinensis","P.platyrhinos", "S.undulatus","U.nigricaudus"),
                                     labelTheseGenomes = FALSE,
                                     minChrLen2plot = 0,
                                     useOrder = TRUE,
                                     useRegions = TRUE)


# Highlight X and Z.

roi <- data.frame(
  genome = "U.nigricaudus", 
  chr = c("scaffold_6","scaffold_14"), 
  color = c("brown4", "purple"))
sinteny_6n14 <- plot_riparian(
  gsParam = ortologs,
  palette = customPal,
  braidAlpha = .60,
  chrFill = "lightgrey",
  addThemes = ggthemes,
  highlightBed = roi,
  backgroundColor = NULL,
  refGenome = "U.nigricaudus", 
  genomeIDs = c("P.muralis","N.naja","T.elegans","A.carolinensis","P.platyrhinos","S.undulatus","U.nigricaudus")
)

sinteny_6n14_nolabels <- plot_riparian(
  gsParam = ortologs,
  palette = customPal,
  braidAlpha = .60,
  chrFill = "lightgrey",
  addThemes = ggthemes,
  highlightBed = roi,
  backgroundColor = NULL,
  labelTheseGenomes = FALSE,
  refGenome = "U.nigricaudus", 
  genomeIDs = c("P.muralis","N.naja", "T.elegans", "A.carolinensis", "P.platyrhinos", "S.undulatus", "U.nigricaudus")
)

# Highlight just X.

roi14 <- data.frame(
  genome = "U.nigricaudus", 
  chr = "scaffold_14", 
  color = "purple")

sinteny_scaffold14 <- plot_riparian(
  gsParam = ortologs,
  palette = customPal,
  braidAlpha = .60,
  chrFill = "lightgrey",
  addThemes = ggthemes,
  highlightBed = roi14, 
  backgroundColor = NULL,
  labelTheseGenomes = FALSE,
  refGenome = "U.nigricaudus", 
  genomeIDs = c("P.muralis","N.naja", "T.elegans","A.carolinensis", "P.platyrhinos", "S.undulatus", "U.nigricaudus")
)

# Synteny with micros from Anolis (for better visualization)

roi_micros_anolis <- data.frame(
  genome = "U.nigricaudus", 
  chr = c("scaffold_7","scaffold_8","scaffold_9","scaffold_10","scaffold_11","scaffold_12","scaffold_13","scaffold_14")
  )
 
 sinteny_micros_anolis<- plot_riparian(
  gsParam = ortologs,
  palette = customPal,
  braidAlpha = .60,
  chrFill = "lightgrey",
  addThemes = ggthemes,
  highlightBed = roi_microsanolis,
  backgroundColor = NULL,
  minChrLen2plot = 0,
  refGenome = "U.nigricaudus", 
  genomeIDs = c("A.carolinensis","U.nigricaudus")
)


